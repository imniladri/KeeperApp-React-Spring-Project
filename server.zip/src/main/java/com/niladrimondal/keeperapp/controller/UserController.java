package com.niladrimondal.keeperapp.controller;

import com.niladrimondal.keeperapp.entity.User;
import com.niladrimondal.keeperapp.exception.UserNotFoundException;
import com.niladrimondal.keeperapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class UserController {
	
	@Autowired
	private UserService userService;

	@GetMapping("/login")
	public String getLogin() {
		return "Login";
	}

	@PostMapping("/login")
	public User getUserLogin(@RequestBody Map<String, Object> payLoadData) {
		String loginUsername = (String) payLoadData.get("username");
		String loginPassword = (String) payLoadData.get("password");

		boolean validUser = userService.validateLogin(loginUsername,loginPassword);

		if(validUser) {
			return userService.getUser(loginUsername);
		} else {
			throw new UserNotFoundException("Not Found");
		}
	}

	@GetMapping("/user")
	public List<User> allUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("/user/{username}")
	public User getUserById(@PathVariable("username") String username) {
		return userService.getUser(username);
	}

	@PostMapping("/user")
	public User registerUser(@RequestBody User user) {
		user.setUserid(0);
		return userService.saveUser(user);
	}

}
